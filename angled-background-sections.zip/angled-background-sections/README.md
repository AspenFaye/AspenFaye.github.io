# Angled Background Sections

A Pen created on CodePen.io. Original URL: [https://codepen.io/iDavemay/pen/XEewyY](https://codepen.io/iDavemay/pen/XEewyY).

Using clip-path to make angled backgrounds.