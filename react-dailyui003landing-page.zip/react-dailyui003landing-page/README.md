# React DailyUI - 003 - Landing Page

A Pen created on CodePen.io. Original URL: [https://codepen.io/studiojvla/pen/zBQrWo](https://codepen.io/studiojvla/pen/zBQrWo).

Day 3 of the ReactJS DailyUI project. I'm going to be making 100 different React pens over the next 100 days, in order to get better.

Today is a landing page. I thought I'd hack together a version of Netflix. :)